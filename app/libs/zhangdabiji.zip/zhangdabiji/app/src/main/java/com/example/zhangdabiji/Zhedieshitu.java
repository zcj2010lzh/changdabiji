package com.example.zhangdabiji;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.ExpandableListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class Zhedieshitu extends AppCompatActivity {

    private ArrayList<Group> gData = null;
    private ArrayList<ArrayList<Item>> iData = null;
    private ArrayList<Item> lData = null;
    String text;
    private Context mContext;
    private ExpandableListView exlist_lol;

    SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_zhedieshitu);
        mContext = Zhedieshitu.this;
        preferences = PreferenceManager.getDefaultSharedPreferences(Zhedieshitu.this);
        //数据准备
        gData = new ArrayList<Group>();
        iData = new ArrayList<ArrayList<Item>>();
        gData.add(new Group("AD"));
        gData.add(new Group("AP"));
        gData.add(new Group("zx"));

        lData = new ArrayList<Item>();

        lData.add(new Item("剑圣"));
        lData.add(new Item("德莱文"));
        lData.add(new Item("男枪"));
        lData.add(new Item("韦鲁斯"));
        iData.add(lData);
        //AP组
        lData = new ArrayList<Item>();
        lData.add(new Item("提莫"));
        lData.add(new Item("安妮"));
        lData.add(new Item("天使"));
        lData.add(new Item("泽拉斯"));
        lData.add(new Item("狐狸"));
        iData.add(lData);
        //TANK组
        lData = new ArrayList<Item>();
        lData.add(new Item("诺手"));
        lData.add(new Item("德邦"));
        lData.add(new Item("奥拉夫"));
        lData.add(new Item("龙女"));
        lData.add(new Item("狗熊"));
        iData.add(lData);
        exlist_lol = findViewById(R.id.exlist_lol1);
        //为列表设置点击事件
        MyBaseExpandableListAdapter myAdapter = new MyBaseExpandableListAdapter(gData, iData, Zhedieshitu.this);
        exlist_lol.setAdapter(myAdapter);

        exlist_lol.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {

                /*    String token=   preferences.getString("token","");
                        OkHttpClient client = new OkHttpClient();//创建OkHttpClient对象
                        Request request = new Request.Builder()
                                .url("http://47.103.205.169/api/summary/?token="+token)//请求接口。如果需要传参拼接到接口后面。
                                .build();//创建Request 对象
                        client.newCall(request).enqueue(new Callback() {
                            public void onFailure(@NotNull Call call, @NotNull IOException e) {

                            }

                            @Override
                            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                                final String responsedata=response.body().string();
                                try {

                                    final JSONArray array=new JSONArray(responsedata);
                                    for(int i=0;i<array.length();i++) {
                                        JSONObject object = array.getJSONObject(0);
                                        text = object.getString("text");
                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
*/
                        File file1=new File(Environment.getExternalStorageDirectory().getAbsolutePath() +"/tencent/QQfile_recv") ;

                //写字符串进word



                File file=new File(file1,"test.doc");
                File file2=new File(file1,"zcj.doc");
                if (file.exists()){}
                else {
                    try {
                        Toast.makeText(mContext, ""+ file.createNewFile(), Toast.LENGTH_SHORT).show();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                if (file2.exists()){}
                else {

                        try {
                            file2.createNewFile();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
              /*  try {
                    InputStream in=new FileInputStream(file2);
                    HWPFDocument docyou=new HWPFDocument(in);
                    Range range=docyou.getRange();
                    range.insertAfter("jsgjirjgirj");
                    OutputStream os=new FileOutputStream(file);
                    docyou.write(os);

                } catch (IOException e) {
                    e.printStackTrace();
                }*/


             /*   Intent intent = new Intent(Zhedieshitu.this, WendangJiazaiyemian.class);
                intent.putExtra("fileurl","afafag");
              startActivity(intent);*/


                return false;
            }
        });
    }
}