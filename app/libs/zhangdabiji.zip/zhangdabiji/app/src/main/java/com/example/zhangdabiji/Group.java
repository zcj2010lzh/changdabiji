package com.example.zhangdabiji;

public class Group {
    public String getgName() {
        return name;
    }

    public void setgName(String name) {
        this.name = name;
    }
Group(String name){
        this.name=name;
}
    protected    String name;
}
