package com.example.zhangdabiji;


import android.app.Application;

/**
 * Created by huangasys on 2018/4/11.15:54
 */

public class HApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        //初始化X5内核

    }
    public  static void ss(){

    }
}
