package com.example.zhangdabiji;

import android.Manifest;
import android.content.ContentUris;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.navigation.NavigationView;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import de.hdodenhof.circleimageview.CircleImageView;

import static com.example.zhangdabiji.FileAdapter.mfileList;
import static com.example.zhangdabiji.FileAdapter.positionSet;
import static org.litepal.LitePalApplication.getContext;


public class MainActivity extends AppCompatActivity implements ViewPager.OnPageChangeListener {

    Button  wendang,wode,gaishu;
    private ViewPager vpager;
    public static Boolean viewpagerisskip=true;
    Boolean isexit=false;
    public static final int takePhone = 1;
    public Button genghuantouxiang;
    public CircleImageView yonghuyemian_circle;
    View head;
    TextView xuehao;
    String xx;
    String imagePath=null;
    public Bitmap bitmap;
    private Uri imguri;
    private SharedPreferences preferences;
    private  SharedPreferences.Editor editor;;
    private MyFragmentPagerAdapter mAdapter;
    //几个代表页面的常量
    private DrawerLayout drawerLayout;
  public static   TextView gejiantextView,sanchu;
    public List<View> views;
  static   CheckBox quanxuan;
    int windowheight;
    public static final int PAGE_ONE = 0;
    public static final int PAGE_TWO = 1;
    public static final int PAGE_THREE= 2;
    public  static  View view;
    FileAdapter.ViewHolder holder;
    static Boolean  danxuam=true;
  static   LinearLayout l1,l2;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       view = LayoutInflater.from(MainActivity.this).inflate(R.layout.item_popip, null, false);
       wode=findViewById(R.id.main_wode);
       gaishu=findViewById(R.id.main_paiming);
       gejiantextView=findViewById(R.id.kejian);
      wendang=findViewById(R.id.main_wendang);
      l1=findViewById(R.id.main_l1);
      l2=findViewById(R.id.main_l2);
     sanchu=findViewById(R.id.main_sanchu);
     quanxuan=findViewById(R.id.main_quanxuan);


     drawerLayout=findViewById(R.id.main_drawlayout);
        WindowManager wm=this.getWindowManager();
     windowheight=wm.getDefaultDisplay().getWidth();
       // Layout main_head=drawerLayout.getL
     quanxuan.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
         @Override
         public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
             if (quanxuan.isChecked()){
                 positionSet.clear();
                 for(int i = 0; i< mfileList.size(); i++){
                     //Toast.makeText(MainActivity.this, ""+FileAdapter.mfileList.size(), Toast.LENGTH_SHORT).show();
                     FileAdapter.ViewHolder holder = (FileAdapter.ViewHolder) WendangYemian.recyclerView.findViewHolderForAdapterPosition(i);
                     if (holder==null){
                         Toast.makeText(MainActivity.this, ""+i, Toast.LENGTH_SHORT).show();
                         return;}
                     positionSet.add(i);
                     holder.fileCheck.setChecked(true);
                     holder.fileCheck.setVisibility(View.VISIBLE);
                 }
             }
                   else{
                       for (int i : positionSet){
                           FileAdapter.ViewHolder  holder= (FileAdapter.ViewHolder) WendangYemian.recyclerView.findViewHolderForAdapterPosition(i);
                           if (holder==null)
                               continue;
                           holder.fileCheck.setVisibility(View.GONE);
                           holder.fileCheck.setChecked(false);
                       }
                   }
         }
     });
     editor= PreferenceManager.getDefaultSharedPreferences( MainActivity.this).edit();
      preferences=PreferenceManager.getDefaultSharedPreferences(MainActivity.this);
        if (ZhuCe.zuceActivity!=null)
       ZhuCe.zuceActivity.finish();

      wode.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {
              vpager.setCurrentItem(2);
          }
      });
        gaishu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                vpager.setCurrentItem(1);
            }
        });
      wendang.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {
              vpager.setCurrentItem(0);
          }
      });
      editor.putBoolean("yonghuiszhidongdenglu",true);
      editor.apply();
        mAdapter = new MyFragmentPagerAdapter(getSupportFragmentManager());

        sanchu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!quanxuan.isChecked()) {
                    FileAdapter.delete();
                    positionSet.clear();
                    WendangYemian.adapter.notifyDataSetChanged();
                }else {
                    quanxuan.setChecked(false);
                    String s;
                    s=preferences.getString("bukandewendang","");
                    for(int i=0;i< mfileList.size();i++)
                        s=s+i+",";
                    editor.putString("bukandewendang",s);
                    editor.apply();
                    mfileList.clear();
                    WendangYemian.adapter.notifyDataSetChanged();
                }
            }
        });
           bindViews();
        NavigationView navigationView = findViewById(R.id.yonghuyemian_navigation);
        navigationView.setMinimumWidth(windowheight);
        head=navigationView.getHeaderView(0);
        xuehao=head.findViewById(R.id.yonghuyemian_xuehao);
        xuehao.setText(preferences.getString("yonghuxuehao","201803310"));
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.dengluzhuce:
                        Intent intent = new Intent(MainActivity.this, ZhuCe.class);
                        editor=PreferenceManager.getDefaultSharedPreferences(getContext()).edit();
                        editor.putBoolean("yonghuiszhidongdenglu",false);
                        editor.putBoolean("is",true);
                        editor.apply();
                        startActivity(intent);
                        MainActivity.this.onBackPressed();
                        break;
                    case R.id.menu_chakanqitawendang:
                        Intent intent1 = new Intent(getContext(), Zhedieshitu.class);
                        startActivity(intent1);
                        break;
                }
                return false;
            }
        });

        //menu.se
        yonghuyemian_circle = head.findViewById(R.id.yonghuyemian_circleView);
        preferences = PreferenceManager.getDefaultSharedPreferences(getContext());
        editor = PreferenceManager.getDefaultSharedPreferences(getContext()).edit();
        imagePath = preferences.getString("imgsource", "");
        if (yonghuyemian_circle.getBackground() == null)
            yonghuyemian_circle.setImageResource(R.drawable.touxiang);
        if (!imagePath.equals(""))
            displayImage(imagePath);
        //Toast.makeText(getContext(), ""+preferences.getString("imgsource",""), Toast.LENGTH_SHORT).show();
        genghuantouxiang = head.findViewById(R.id.yonghuyemian_genhuantouxiang);
        genghuantouxiang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ContextCompat.checkSelfPermission(getContext(), Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
                } else {
                    openAlbum();
                }
            }
        });

    }



    private void bindViews() {
        vpager = (ViewPager) findViewById(R.id.vpager);
        vpager.setAdapter(mAdapter);
        vpager.setCurrentItem(0);
        vpager.setOffscreenPageLimit(2);
        vpager.addOnPageChangeListener(this);
    }
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
    }

    @Override
    public void onPageSelected(int position) {
    }


    @Override
    public void onPageScrollStateChanged(int state) {
        //state的状态有三个，0表示什么都没做，1正在滑动，2滑动完毕
        if (state == 2) {
            switch (vpager.getCurrentItem()) {
                case PAGE_ONE:
                wode.setBackgroundColor(Color.parseColor("#00000000"));
                    gaishu.setBackgroundColor(Color.parseColor("#00000000"));
                    wendang.setBackgroundColor(Color.parseColor("#23000000"));
                   if (WendangYemian.swipe){
                       if (MainActivity.gejiantextView.getVisibility()==View.INVISIBLE)
                           MainActivity.gejiantextView.setVisibility(View.VISIBLE);
                   }
                   if (l1.getVisibility()==View.VISIBLE)

                    break;
                case PAGE_TWO:
                    gaishu.setBackgroundColor(Color.parseColor("#23000000"));
                    wode.setBackgroundColor(Color.parseColor("#00000000"));
                    wendang.setBackgroundColor(Color.parseColor("#00000000"));
                    if (MainActivity.gejiantextView.getVisibility()==View.VISIBLE)
                        MainActivity.gejiantextView.setVisibility(View.INVISIBLE);
                    break;
                case PAGE_THREE:
                    wode.setBackgroundColor(Color.parseColor("#23000000"));
                    gaishu.setBackgroundColor(Color.parseColor("#00000000"));
                    wendang.setBackgroundColor(Color.parseColor("#00000000"));
                    if (MainActivity.gejiantextView.getVisibility()==View.VISIBLE)
                        MainActivity.gejiantextView.setVisibility(View.INVISIBLE);
                    break;
            }
        }
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {//当返回按键被按下
            //调用exit()方法
            if (l1.getVisibility()==View.VISIBLE){
                danxuam=true;
                quanxuan.setChecked(false);
                for (int i : positionSet){
                    FileAdapter.ViewHolder  holder= (FileAdapter.ViewHolder) WendangYemian.recyclerView.findViewHolderForAdapterPosition(i);
                    if (holder==null)
                        continue;
                    holder.fileCheck.setVisibility(View.GONE);
                    holder.fileCheck.setChecked(false);
                }
                l1.setVisibility(View.INVISIBLE);
                l2.setVisibility(View.VISIBLE);
            }

            else
            exit();
        }
        return false;
    }

    //被调用的exit()方法
    private void exit() {
        Timer timer;//声明一个定时器
        if (!isexit) {  //如果isExit为false,执行下面代码
            isexit = true;  //改变值为true
            Toast.makeText(MainActivity.this, "再按一次退出", Toast.LENGTH_SHORT).show();  //弹出提示
            timer = new Timer();  //得到定时器对象
            //执行定时任务,两秒内如果没有再次按下,把isExit值恢复为false,再次按下返回键时依然会进入if这段代码
            timer.schedule(new TimerTask() {
                @Override
                public void run() {
                    isexit = false;
                }
            }, 2000);
        } else {//如果两秒内再次按下了返回键,这时isExit的值已经在第一次按下时赋值为true了,因此不会进入if后的代码,直接执行下面的代码
            finish();
        }
    }



        public void onDestory()
        {
            super.onDestroy();
            this.finish();
            android.os.Process.killProcess(android.os.Process.myPid());
            System.exit(0);
        }
    protected   static Boolean initPopWindow(View v) {
        Button btn_xixi = (Button) view.findViewById(R.id.btn_xixi);
        //1.构造一个PopupWindow，参数依次是加载的View，宽高
        final PopupWindow popWindow = new PopupWindow(view,
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, true);

        popWindow.setAnimationStyle(R.anim.anim_pop);  //设置加载动画

        //这些为了点击非PopupWindow区域，PopupWindow会消失的，如果没有下面的
        //代码的话，你会发现，当你把PopupWindow显示出来了，无论你按多少次后退键
        //PopupWindow并不会关闭，而且退不出程序，加上下述代码可以解决这个问题
        popWindow.setTouchable(true);
        popWindow.setTouchInterceptor(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return false;
                // 这里如果返回true的话，touch事件将被拦截
                // 拦截后 PopupWindow的onTouchEvent不被调用，这样点击外部区域无法dismiss
            }
        });
        popWindow.setBackgroundDrawable(new ColorDrawable(0x00000000));    //要为popWindow设置一个背景才有效


        //设置popupWindow显示的位置，参数依次是参照View，x轴的偏移量，y轴的偏移量
        popWindow.showAsDropDown(v, 50, 0);

        //设置popupWindow里的按钮的事件
        btn_xixi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(3000);
                }catch (InterruptedException e){
                    e.printStackTrace();
                }
            }
        });
        return  true;
    }
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode){
            case  1:
                if (grantResults.length>0&&grantResults[0]==PackageManager.PERMISSION_GRANTED)
                    openAlbum();
                else {
                    Toast.makeText(getContext(), "you denied thr permisson", Toast.LENGTH_SHORT).show();
                }
                break;
            default:
                break;
        }
    }
    public void openAlbum() {
        Intent intentn = new Intent("android.intent.action.GET_CONTENT");
        intentn.setType("image/*");
        startActivityForResult(intentn, takePhone);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch ((requestCode)) {
            case takePhone:
                handImageOnkitKat(data);
        }
    }
    private  void handImageOnkitKat(Intent data){
        imagePath=null;
        if(data==null)
            return;
        Uri uri=data.getData();

        if (DocumentsContract.isDocumentUri(getContext(),uri)){
            String docId=DocumentsContract.getDocumentId(uri);
            if ("com.android.providers.media.documents".equals(uri.getAuthority())){
                String id=docId.split(":")[1];
                String seliction= MediaStore.Images.Media._ID+"="+id;
                imagePath=getImagePath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,seliction);
            }else  if("com.android. providers.downloads.document".equals(uri.getAuthority())){
                Uri cotentUri= ContentUris.withAppendedId(uri.parse("content://downloads/public_downloads"),Long.valueOf(docId));
                imagePath=getImagePath(cotentUri,null);
            }}
        else  if ("content".equalsIgnoreCase(uri.getScheme())){
            imagePath=getImagePath(uri,null);
        }
        else  if ("file".equalsIgnoreCase(uri.getScheme())){
            imagePath=uri.getPath();
        }
        editor.putString("imgsource",imagePath);
        editor.apply();
        displayImage(imagePath);
    }
    private  String getImagePath(Uri uri,String selection){
        String path=null;
        Cursor cursor=MainActivity.this. getContentResolver().query(uri,null,selection,null,null);
        if (cursor!=null){
            if (cursor.moveToFirst()){
                path=cursor.getString(cursor.getColumnIndex(MediaStore.Images.Media.DATA));
            }
            cursor.close();
        }
        return path;
    }
    private  void displayImage(String imagePath) {
        if (imagePath != null) {
            xx = imagePath;
            bitmap = BitmapFactory.decodeFile(imagePath);

            // Toast.makeText(getContext(), ""+imagePath, Toast.LENGTH_SHORT).show();
            // imagePath= preferences.getString("imgsource","");
            //Toast.makeText(getContext(), ""+preferences.getString("imgsource",""), Toast.LENGTH_SHORT).show();
            yonghuyemian_circle.setImageBitmap(bitmap);
        } else {
            Toast.makeText(getContext(), "failed to get image", Toast.LENGTH_SHORT).show();
        }
    }
}


